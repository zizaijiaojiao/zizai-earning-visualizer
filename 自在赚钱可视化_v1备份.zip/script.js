(() => {
  'use strict';

  const STORAGE_KEY = 'zizai-earnings-v1';
  const ZONE = 'Asia/Shanghai';
  const weekdayNames = ['日', '一', '二', '三', '四', '五', '六'];
  const dateFormatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: ZONE, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
  });
  const moneyFormatter = new Intl.NumberFormat('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const wholeFormatter = new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 0 });
  const $ = (id) => document.getElementById(id);
  const todayParts = () => {
    const parts = Object.fromEntries(dateFormatter.formatToParts(new Date()).filter(p => p.type !== 'literal').map(p => [p.type, p.value]));
    return { date: `${parts.year}-${parts.month}-${parts.day}`, seconds: Number(parts.hour) * 3600 + Number(parts.minute) * 60 + Number(parts.second), hour: parts.hour, minute: parts.minute, second: parts.second };
  };
  const defaultState = () => ({
    version: 1,
    settings: {
      basePay: 1100, overtimePay: 225, rate: 0.9, rateCustomized: false,
      goalAmount: 12000, goalName: 'iPhone 18 Pro · 银白色',
      startTime: '09:00', endTime: '18:00', breakStart: '12:00', breakEnd: '13:00', overtimeEnd: '20:00',
      startDate: todayParts().date, workdays: [1, 2, 3, 4, 5]
    },
    days: {}
  });
  const defaultSettings = defaultState().settings;
  const validDate = (value) => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
  const timeValue = (value) => /^\d{2}:\d{2}$/.test(value || '') ? Number(value.slice(0, 2)) * 60 + Number(value.slice(3)) : NaN;
  const validTime = (value) => Number.isFinite(timeValue(value)) && timeValue(value) >= 0 && timeValue(value) < 1440 && Number(value.slice(3)) < 60;
  const safeNumber = (value, fallback, min, max) => Number.isFinite(Number(value)) && Number(value) >= min && Number(value) <= max ? Number(value) : fallback;

  function sanitizeState(source) {
    if (!source || typeof source !== 'object' || source.version !== 1 || !source.settings || typeof source.settings !== 'object' || !source.days || typeof source.days !== 'object' || Array.isArray(source.days)) throw new Error('文件不是有效的「自在赚钱可视化」备份。');
    const s = source.settings;
    const settings = {
      basePay: safeNumber(s.basePay, defaultSettings.basePay, 0, 1000000),
      overtimePay: safeNumber(s.overtimePay, defaultSettings.overtimePay, 0, 1000000),
      rate: safeNumber(s.rate, defaultSettings.rate, 0.000001, 100),
      rateCustomized: Boolean(s.rateCustomized),
      goalAmount: safeNumber(s.goalAmount, defaultSettings.goalAmount, 0.01, 1000000000),
      goalName: typeof s.goalName === 'string' && s.goalName.trim() ? s.goalName.trim().slice(0, 50) : defaultSettings.goalName,
      startTime: validTime(s.startTime) ? s.startTime : defaultSettings.startTime,
      endTime: validTime(s.endTime) ? s.endTime : defaultSettings.endTime,
      breakStart: validTime(s.breakStart) ? s.breakStart : defaultSettings.breakStart,
      breakEnd: validTime(s.breakEnd) ? s.breakEnd : defaultSettings.breakEnd,
      overtimeEnd: validTime(s.overtimeEnd) ? s.overtimeEnd : defaultSettings.overtimeEnd,
      startDate: validDate(s.startDate) ? s.startDate : defaultSettings.startDate,
      workdays: Array.isArray(s.workdays) ? [...new Set(s.workdays.filter(n => Number.isInteger(n) && n >= 0 && n <= 6))] : defaultSettings.workdays
    };
    if (!validSchedule(settings)) throw new Error('备份中的工作时间设置无效。');
    const days = {};
    for (const [date, entry] of Object.entries(source.days)) {
      if (!validDate(date) || !entry || typeof entry !== 'object') continue;
      const status = ['work', 'off'].includes(entry.status) ? entry.status : undefined;
      const overtime = entry.overtime === true;
      if (status || overtime) days[date] = { ...(status ? { status } : {}), ...(overtime ? { overtime: true } : {}) };
    }
    return { version: 1, settings, days };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? sanitizeState(JSON.parse(raw)) : defaultState();
    } catch (_) { return defaultState(); }
  }
  let state = loadState();
  let selectedDate = todayParts().date;
  let calendarYear = Number(selectedDate.slice(0, 4));
  let calendarMonth = Number(selectedDate.slice(5, 7)) - 1;
  let historyCache = { date: '', hkd: 0, days: 0 };
  let toastTimer;

  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch (_) { showToast('浏览器无法保存记录，请使用导出备份。'); }
    historyCache.date = '';
  }
  function showToast(message) {
    const toast = $('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 3500);
  }
  function validSchedule(s) {
    const a = timeValue(s.startTime), b = timeValue(s.breakStart), c = timeValue(s.breakEnd), d = timeValue(s.endTime), e = timeValue(s.overtimeEnd);
    return [s.startTime, s.breakStart, s.breakEnd, s.endTime, s.overtimeEnd].every(validTime) && a < b && b < c && c < d && d < e;
  }
  function dateFromKey(key) { return new Date(`${key}T00:00:00Z`); }
  function keyFromDate(date) { return date.toISOString().slice(0, 10); }
  function nextDate(key) { const d = dateFromKey(key); d.setUTCDate(d.getUTCDate() + 1); return keyFromDate(d); }
  function weekday(key) { return dateFromKey(key).getUTCDay(); }
  function isWorkday(key) {
    const override = state.days[key]?.status;
    if (override === 'work') return true;
    if (override === 'off') return false;
    return state.settings.workdays.includes(weekday(key));
  }
  function hasOvertime(key) { return isWorkday(key) && state.days[key]?.overtime === true; }
  function scheduleSeconds() {
    const s = state.settings;
    return {
      start: timeValue(s.startTime) * 60,
      breakStart: timeValue(s.breakStart) * 60,
      breakEnd: timeValue(s.breakEnd) * 60,
      end: timeValue(s.endTime) * 60,
      overtimeEnd: timeValue(s.overtimeEnd) * 60
    };
  }
  function elapsed(now, start, end) { return Math.max(0, Math.min(now, end) - start); }
  function earningsAt(key, seconds) {
    if (key < state.settings.startDate || !isWorkday(key)) return { hkd: 0, paidSeconds: 0, possibleSeconds: 0 };
    const t = scheduleSeconds();
    const baseSeconds = (t.breakStart - t.start) + (t.end - t.breakEnd);
    const paidBase = elapsed(seconds, t.start, t.breakStart) + elapsed(seconds, t.breakEnd, t.end);
    const overtime = hasOvertime(key);
    const overtimeSeconds = overtime ? t.overtimeEnd - t.end : 0;
    const paidOvertime = overtime ? elapsed(seconds, t.end, t.overtimeEnd) : 0;
    return {
      hkd: state.settings.basePay * paidBase / baseSeconds + (overtime ? state.settings.overtimePay * paidOvertime / overtimeSeconds : 0),
      paidSeconds: paidBase + paidOvertime,
      possibleSeconds: baseSeconds + overtimeSeconds
    };
  }
  function historyBefore(today) {
    if (historyCache.date === today) return historyCache;
    let hkd = 0, days = 0;
    if (state.settings.startDate < today) {
      for (let key = state.settings.startDate; key < today; key = nextDate(key)) {
        if (isWorkday(key)) { hkd += state.settings.basePay + (hasOvertime(key) ? state.settings.overtimePay : 0); days++; }
      }
    }
    historyCache = { date: today, hkd, days };
    return historyCache;
  }
  const hkd = n => `HK$${moneyFormatter.format(n)}`;
  const rmb = n => `¥${moneyFormatter.format(n)}`;
  const rmbWhole = n => `¥${wholeFormatter.format(Math.ceil(n))}`;
  const readableDate = key => { const [y, m, d] = key.split('-').map(Number); return `${y}年${m}月${d}日`; };

  function renderLive() {
    const now = todayParts();
    const s = state.settings;
    const history = historyBefore(now.date);
    const today = earningsAt(now.date, now.seconds);
    const totalHkd = history.hkd + today.hkd;
    const totalRmb = totalHkd * s.rate;
    const remaining = Math.max(0, s.goalAmount - totalRmb);
    const progress = Math.min(100, totalRmb / s.goalAmount * 100);
    const t = scheduleSeconds();
    const working = now.date >= s.startDate && isWorkday(now.date);
    let status = '今天休息，好好充电';
    if (working) {
      if (now.seconds < t.start) status = '还没上班，先享受早晨';
      else if (now.seconds >= t.breakStart && now.seconds < t.breakEnd) status = '午休中，下午继续赚';
      else if (now.seconds >= (hasOvertime(now.date) ? t.overtimeEnd : t.end)) status = '今日计时已结束';
      else if (now.seconds >= t.end) status = '加班进行中 · 每秒都在增长';
      else status = '工作进行中 · 每秒都在增长';
    }
    if (now.date < s.startDate) status = '尚未到累计开始日期';
    $('earningStatus').textContent = status;
    $('todayHkd').textContent = moneyFormatter.format(today.hkd);
    $('todayRmb').textContent = rmb(today.hkd * s.rate);
    $('totalHkd').textContent = hkd(totalHkd);
    $('totalRmb').textContent = rmb(totalRmb);
    $('totalDays').textContent = `从 ${readableDate(s.startDate)} 起 · ${history.days + (working ? 1 : 0)} 个工作日`;
    $('clockLabel').textContent = `北京时间 ${now.hour}:${now.minute}:${now.second}`;
    $('todayDate').textContent = `${readableDate(now.date)} · 星期${weekdayNames[weekday(now.date)]}`;
    $('miniDate').textContent = `${Number(now.date.slice(5, 7))}月${Number(now.date.slice(8))}日 星期${weekdayNames[weekday(now.date)]}`;
    $('shiftSummary').textContent = `${s.startTime} — ${hasOvertime(now.date) ? s.overtimeEnd : s.endTime}`;
    $('rateNote').textContent = s.rateCustomized ? `按 1 港币 = ${s.rate} 元换算` : `演示汇率 ${s.rate}，可在设置中修改`;
    const workProgress = today.possibleSeconds ? Math.min(100, today.paidSeconds / today.possibleSeconds * 100) : 0;
    $('workPercent').textContent = `${Math.round(workProgress)}%`;
    const remainingMinutes = Math.max(0, Math.ceil((today.possibleSeconds - today.paidSeconds) / 60));
    $('workTimeLeft').textContent = !working ? '今天未安排工作' : workProgress >= 100 ? '今日工作已完成' : now.seconds < t.start ? '尚未开始' : `剩余约 ${Math.floor(remainingMinutes / 60)} 小时 ${remainingMinutes % 60} 分钟`;
    $('goalName').textContent = s.goalName;
    $('goalTarget').textContent = rmbWhole(s.goalAmount);
    $('goalRemaining').textContent = rmbWhole(remaining);
    $('goalRemainingLabel').textContent = remaining <= 0 ? '心愿已达成！' : '还差这么多';
    $('savedRmb').textContent = rmb(totalRmb);
    $('goalPercent').textContent = `${progress.toFixed(1)}%`;
    $('goalProgress').setAttribute('aria-valuenow', progress.toFixed(1));
    $('progressFill').style.width = `${progress}%`;
    $('goalBadge').textContent = remaining <= 0 ? '心愿达成 ✦' : '目标进行中';
    $('todayOvertime').disabled = !working;
    $('todayOvertime').checked = hasOvertime(now.date);
    $('overtimeHint').textContent = !working ? '今天不是工作日，可在日历中标记额外上班' : '开启后，加班费会在加班时段逐秒增长';
    if (selectedDate === now.date) updateSelectedEditor();
  }

  function renderStatic() {
    const s = state.settings;
    $('startTimeText').textContent = s.startTime;
    $('breakTimeText').textContent = `${s.breakStart} – ${s.breakEnd}`;
    $('endTimeText').textContent = s.endTime;
    $('overtimeTimeText').textContent = `${s.endTime} – ${s.overtimeEnd}`;
    $('basePayText').textContent = `+ ${hkd(s.basePay)}`;
    $('overtimePayText').textContent = `+ ${hkd(s.overtimePay)}`;
    renderCalendar();
    renderLive();
  }

  function renderCalendar() {
    $('calendarMonth').textContent = `${calendarYear}年${calendarMonth + 1}月`;
    const grid = $('calendarGrid');
    grid.replaceChildren();
    const first = new Date(Date.UTC(calendarYear, calendarMonth, 1));
    const offset = (first.getUTCDay() + 6) % 7;
    const start = new Date(Date.UTC(calendarYear, calendarMonth, 1 - offset));
    const today = todayParts().date;
    for (let i = 0; i < 42; i++) {
      const date = new Date(start);
      date.setUTCDate(start.getUTCDate() + i);
      const key = keyFromDate(date);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'calendar-day';
      button.textContent = String(date.getUTCDate());
      button.setAttribute('role', 'gridcell');
      button.setAttribute('aria-label', `${readableDate(key)}，${isWorkday(key) ? hasOvertime(key) ? '加班日' : '工作日' : '休息日'}`);
      button.setAttribute('aria-selected', String(key === selectedDate));
      if (date.getUTCMonth() !== calendarMonth) button.classList.add('is-outside');
      if (key < state.settings.startDate) button.classList.add('is-before-start');
      if (isWorkday(key)) button.classList.add('is-work'); else button.classList.add('is-off');
      if (hasOvertime(key)) button.classList.add('is-overtime');
      if (key === selectedDate) button.classList.add('is-selected');
      if (key === today) button.classList.add('is-today');
      button.addEventListener('click', () => {
        selectedDate = key;
        if (date.getUTCMonth() !== calendarMonth) { calendarYear = date.getUTCFullYear(); calendarMonth = date.getUTCMonth(); renderCalendar(); }
        else { grid.querySelectorAll('.calendar-day').forEach(b => { b.classList.remove('is-selected'); b.setAttribute('aria-selected', 'false'); }); button.classList.add('is-selected'); button.setAttribute('aria-selected', 'true'); }
        updateSelectedEditor();
      });
      grid.appendChild(button);
    }
    updateSelectedEditor();
  }
  function updateSelectedEditor() {
    const entry = state.days[selectedDate] || {};
    const today = todayParts().date;
    $('selectedDateLabel').textContent = `${readableDate(selectedDate)} · 星期${weekdayNames[weekday(selectedDate)]}`;
    $('selectedDateInfo').textContent = selectedDate < state.settings.startDate ? '早于累计开始日期，不计入收入' : selectedDate > today ? '可提前安排工作或加班' : selectedDate === today ? `${hkd(earningsAt(selectedDate, todayParts().seconds).hkd)} · 今日已赚` : isWorkday(selectedDate) ? `${hkd(state.settings.basePay + (hasOvertime(selectedDate) ? state.settings.overtimePay : 0))} · 当日估算` : '休息日，不计入收入';
    $('dayStatus').value = entry.status || 'default';
    $('dayOvertime').checked = hasOvertime(selectedDate);
    $('dayOvertime').disabled = !isWorkday(selectedDate);
  }
  function updateDay(patch) {
    const next = { ...(state.days[selectedDate] || {}), ...patch };
    if (!next.status) delete next.status;
    if (!next.overtime || next.status === 'off') delete next.overtime;
    if (Object.keys(next).length) state.days[selectedDate] = next;
    else delete state.days[selectedDate];
    saveState(); renderCalendar(); renderLive();
  }

  function fillForm() {
    const form = $('settingsForm');
    for (const [key, value] of Object.entries(state.settings)) if (form.elements.namedItem(key)) form.elements.namedItem(key).value = value;
    $('weekdaySettings').replaceChildren();
    for (let day = 1; day <= 7; day++) {
      const n = day === 7 ? 0 : day;
      const label = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'checkbox'; input.name = 'workday'; input.value = String(n); input.checked = state.settings.workdays.includes(n);
      label.append(input, document.createTextNode(`周${weekdayNames[n]}`));
      $('weekdaySettings').appendChild(label);
    }
    $('formError').hidden = true;
  }
  let modalTrigger = null;
  function openSettings(trigger) { modalTrigger = trigger; fillForm(); $('settingsBackdrop').hidden = false; document.body.style.overflow = 'hidden'; $('closeSettings').focus(); }
  function closeSettings() { $('settingsBackdrop').hidden = true; document.body.style.overflow = ''; modalTrigger?.focus(); }
  function saveSettings(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const s = {
      basePay: Number(data.get('basePay')), overtimePay: Number(data.get('overtimePay')),
      rate: Number(data.get('rate')), rateCustomized: true,
      goalAmount: Number(data.get('goalAmount')), goalName: String(data.get('goalName') || '').trim(),
      startTime: String(data.get('startTime')), endTime: String(data.get('endTime')),
      breakStart: String(data.get('breakStart')), breakEnd: String(data.get('breakEnd')),
      overtimeEnd: String(data.get('overtimeEnd')), startDate: String(data.get('startDate')),
      workdays: data.getAll('workday').map(Number)
    };
    let error = '';
    if (![s.basePay, s.overtimePay, s.rate, s.goalAmount].every(Number.isFinite) || s.basePay < 0 || s.overtimePay < 0 || s.rate <= 0 || s.goalAmount <= 0) error = '请填写有效的工资、汇率和目标金额。';
    else if (!s.goalName) error = '请填写心愿名称。';
    else if (!validSchedule(s)) error = '时间顺序应为：上班、午休开始、午休结束、正常下班、加班结束。';
    else if (!validDate(s.startDate)) error = '请选择有效的累计开始日期。';
    else if (!s.workdays.length) error = '请至少选择一个每周上班日；单日休假可在日历中修改。';
    if (error) { $('formError').textContent = error; $('formError').hidden = false; return; }
    state.settings = s;
    saveState(); renderStatic(); closeSettings(); showToast('设置已保存，收入进度已重新计算。');
  }

  function exportData() {
    const blob = new Blob([JSON.stringify({ ...state, exportedAt: new Date().toISOString() }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `自在赚钱可视化备份_${todayParts().date}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('备份已导出，请妥善保存。');
  }
  async function importData(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      if (file.size > 2_000_000) throw new Error('备份文件过大，请检查文件是否正确。');
      const imported = sanitizeState(JSON.parse(await file.text()));
      state = imported;
      selectedDate = todayParts().date;
      calendarYear = Number(selectedDate.slice(0, 4));
      calendarMonth = Number(selectedDate.slice(5, 7)) - 1;
      saveState(); fillForm(); renderStatic(); showToast('备份已导入，记录和设置已恢复。');
    } catch (error) { showToast(error.message || '导入失败，请检查备份文件。'); }
  }

  function sprinkle(count = 12) {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const field = $('coinField');
    for (let i = 0; i < count; i++) {
      const coin = document.createElement('span');
      coin.className = 'fall-coin'; coin.textContent = '¥';
      coin.style.setProperty('--x', `${10 + Math.random() * 80}%`);
      coin.style.setProperty('--dur', `${2.1 + Math.random() * 1.5}s`);
      coin.style.setProperty('--spin', `${(Math.random() - .5) * 950}deg`);
      coin.style.animationDelay = `${Math.random() * .65}s`;
      field.appendChild(coin);
      coin.addEventListener('animationend', () => coin.remove(), { once: true });
    }
  }

  $('openSettings').addEventListener('click', e => openSettings(e.currentTarget));
  $('bottomSettings').addEventListener('click', e => openSettings(e.currentTarget));
  $('closeSettings').addEventListener('click', closeSettings);
  $('cancelSettings').addEventListener('click', closeSettings);
  $('settingsBackdrop').addEventListener('click', e => { if (e.target === $('settingsBackdrop')) closeSettings(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('settingsBackdrop').hidden) closeSettings(); });
  $('settingsForm').addEventListener('submit', saveSettings);
  $('coinButton').addEventListener('click', () => sprinkle(22));
  $('todayOvertime').addEventListener('change', e => {
    selectedDate = todayParts().date;
    updateDay({ overtime: e.target.checked });
    showToast(e.target.checked ? '今天加班已开启，加班费会逐秒累计。' : '今天加班已关闭。');
  });
  $('dayStatus').addEventListener('change', e => updateDay({ status: e.target.value === 'default' ? undefined : e.target.value }));
  $('dayOvertime').addEventListener('change', e => updateDay({ overtime: e.target.checked }));
  $('prevMonth').addEventListener('click', () => { calendarMonth--; if (calendarMonth < 0) { calendarMonth = 11; calendarYear--; } renderCalendar(); });
  $('nextMonth').addEventListener('click', () => { calendarMonth++; if (calendarMonth > 11) { calendarMonth = 0; calendarYear++; } renderCalendar(); });
  $('exportData').addEventListener('click', exportData);
  $('importData').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', importData);
  renderStatic();
  let lastDate = todayParts().date;
  setInterval(() => {
    const now = todayParts();
    if (now.date !== lastDate) { lastDate = now.date; selectedDate = now.date; calendarYear = Number(now.date.slice(0, 4)); calendarMonth = Number(now.date.slice(5, 7)) - 1; renderCalendar(); }
    renderLive();
    if (now.seconds % 7 === 0 && now.date >= state.settings.startDate && isWorkday(now.date)) {
      const t = scheduleSeconds();
      const active = (now.seconds >= t.start && now.seconds < t.breakStart) || (now.seconds >= t.breakEnd && now.seconds < t.end) || (hasOvertime(now.date) && now.seconds >= t.end && now.seconds < t.overtimeEnd);
      if (active && !document.hidden) sprinkle(2);
    }
  }, 1000);
})();
